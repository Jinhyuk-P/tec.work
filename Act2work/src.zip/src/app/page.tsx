import Image from "next/image";
import Counter from './counter/page';

export default function Home() {
  return (
    <>
      {/* Counter Section */}
      <div className="flex flex-col items-center justify-center min-h-screen gap-8">
        <h1 className="text-3xl font-bold text-center mt-8">Counter App</h1>
        <Counter />
      </div>
    </>
  );
}