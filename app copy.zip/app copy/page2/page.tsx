import image from "next/image";
import Link from 'next/link';




export default function Page2() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-72 h-48 bg-blue-700"></div>

    <Link href="/" className="text-blue-500:underline">
      Go to Home
    </Link>

    </div>
    );
}
