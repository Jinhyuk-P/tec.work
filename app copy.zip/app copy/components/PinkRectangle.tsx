interface RectangleProps {
    color: string;
  }
  
  export default function PinkRectangle({ color }: RectangleProps) {
    return <div style={{ backgroundColor: color }}  className="w-32 h-32"></div>;
  }