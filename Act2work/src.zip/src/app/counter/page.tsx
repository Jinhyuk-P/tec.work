'use client';
import { useState } from 'react';

export default function Counter() {
  const [counter, setCounter] = useState(10);
  const [error, setError] = useState<string | null>(null); // For error messages

  const handleIncrement = (e: React.FormEvent) => {
    e.preventDefault();
    setCounter((prev) => prev + 1);
    setError(null); // Clear error when incrementing
  };

  const handleDecrement = (e: React.FormEvent) => {
    e.preventDefault();
    if (counter === 0) {
      setError("⚠️ Cannot decrement below 0!");
    } else {
      setCounter((prev) => prev - 1);
      setError(null);
    }
  };

  const handleReset = (e: React.FormEvent) => {
    e.preventDefault();
    setCounter(10);
    setError(null);
  };

  return (
    <main className="flex flex-col min-h-[calc(100vh-73px)] items-center justify-center gap-6">
      <h1 className="text-4xl font-bold text-blue-800">{counter}</h1>


      {error && <p className="text-red-600 font-medium">{error}</p>}

      {/* Increment, Decrement Buttons*/}
      <form className="flex flex-col items-center gap-4">
        <div className="flex gap-4">
          <button
            type="submit"
            onClick={handleIncrement}
            className="bg-green-600 text-white rounded-md px-4 py-2 hover:bg-green-700 transition-colors"
          >
            Incrementar
          </button>
          <button
            type="submit"
            onClick={handleDecrement}
            className="bg-red-600 text-white rounded-md px-4 py-2 hover:bg-red-700 transition-colors"
          >
            Decrementar
          </button>
        </div>

        {/* Reset Button*/}
        <button
          type="submit"
          onClick={handleReset}
          className="bg-yellow-600 text-white rounded-md px-6 py-2 hover:bg-yellow-700 transition-colors mt-4"
        >
          Reset
        </button>
      </form>
    </main>
  );
}