import Image from "next/image";
import Link from "next/link";

export default function Navigation() {
  return (
    <nav className="w-full px-8 py-4 flex items-center justify-between bg-red-600 shadow-sm relative">
      {/* Logo Section */}
      <div className="flex items-center">
        <Link href="/">
          <Image
            src="/youtubelogo.png"
            alt="Logo"
            width={150}
            height={50}
          />
        </Link>
      </div>

      {/* Centered Navigation Links */}
      <div className="absolute left-1/2 transform -translate-x-1/2 flex gap-6">
        <Link href="/" className="text-white hover:text-gray-200">
          Home
        </Link>
        <Link href="/page1" className="text-white hover:text-gray-200">
          Rectangle
        </Link>
      </div>
    </nav>
  );
}