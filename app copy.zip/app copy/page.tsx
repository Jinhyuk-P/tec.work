import Link from 'next/link';
import Rectangle from './components/Rectangle';
import GreenRectangle from './components/GreenRectangle';
import PinkRectangle from './components/PinkRectangle';


export default function Home() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center gap-6">
      <div className="flex gap-4">
      <Rectangle color="Yellow" />
      <div className="w-32 h-32 bg-blue-700"></div>
      <div className= "w-32 h-32 bg-cyan-700"></div>
      </div>

      
      <div className="flex gap-4">
      <GreenRectangle color= "Green" />
      <div className="w-32 h-32 bg-red-700"></div>
      <div className= "w-32 h-32 bg-orange-700"></div>
      </div>

      <div className= "flex gap-4">
      <PinkRectangle color= "Pink"/>
      <div className= "w-32 h-32 bg-violet-700"></div>
      <div className= "w-32 h-32 bg-indigo-700"></div>
      </div>
      

    <Link href="/page2" className="text-blue-500 underline mt-6">
      Go to Page 2
    </Link>
    </div>
    );
}