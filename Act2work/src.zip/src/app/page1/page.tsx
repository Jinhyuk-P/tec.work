'use client';
import { useState } from 'react';

export default function Home() {
  const defaultColor = 'bg-gray-700'; // Default
  const [color, setColor] = useState(defaultColor); // Initial gray

  // Handle color change
  const handleColorChange = (e: React.FormEvent, selectedColor: string) => {
    e.preventDefault();
    setColor(selectedColor);
  };

  // Reset color
  const handleReset = (e: React.FormEvent) => {
    e.preventDefault();
    setColor(defaultColor);
  };

  return (
    <main className="flex flex-col min-h-screen items-center justify-center gap-8">
      <div className={`w-72 h-48 ${color} transition-colors duration-300 rounded-md shadow-md`}></div>
      <div className="grid grid-cols-2 gap-4">
        <form onSubmit={(e) => handleColorChange(e, 'bg-red-500')}>
          <button
            type="submit"
            className="w-24 bg-red-500 text-white font-bold py-2 px-4 rounded-md hover:opacity-80 transition-opacity"
          >
            Red
          </button>
        </form>

        {/*color change button*/}
        <form onSubmit={(e) => handleColorChange(e, 'bg-green-500')}>
          <button
            type="submit"
            className="w-24 bg-green-500 text-white font-bold py-2 px-4 rounded-md hover:opacity-80 transition-opacity"
          >
            Green
          </button>
        </form>

        <form onSubmit={(e) => handleColorChange(e, 'bg-blue-500')}>
          <button
            type="submit"
            className="w-24 bg-blue-500 text-white font-bold py-2 px-4 rounded-md hover:opacity-80 transition-opacity"
          >
            Blue
          </button>
        </form>

        <form onSubmit={(e) => handleColorChange(e, 'bg-yellow-500')}>
          <button
            type="submit"
            className="w-24 bg-yellow-500 text-white font-bold py-2 px-4 rounded-md hover:opacity-80 transition-opacity"
          >
            Yellow
          </button>
        </form>
      </div>

        {/*reset color button*/}
      <form onSubmit={handleReset}>
        <button
          type="submit"
          className="w-32 bg-gray-500 text-white font-bold py-2 px-4 rounded-md hover:opacity-80 transition-opacity mt-6"
        >
          Reset color
        </button>
      </form>
    </main>
  );
}